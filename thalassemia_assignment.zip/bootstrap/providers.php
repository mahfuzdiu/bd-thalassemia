<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\ObserverServiceProvider::class,
    App\Providers\RepositoryServiceProvider::class,
];
